# 40. Bundeswettbewerb für Informatik - Runde 1

Einsendung von Maximilian Flügel, Klasse 12a
Gymnasium Stadtfeld Wernigerode
